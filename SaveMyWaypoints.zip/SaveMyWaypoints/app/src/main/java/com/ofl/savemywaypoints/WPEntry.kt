package com.ofl.savemywaypoints

class WPEntry(var date: String, var lon: Double, var lat: Double) {
}